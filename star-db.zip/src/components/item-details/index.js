import ItemDetails from './item-details';
export default ItemDetails;