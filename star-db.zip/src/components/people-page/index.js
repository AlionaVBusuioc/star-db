import PeoplePage from './people-page';
export default PeoplePage;