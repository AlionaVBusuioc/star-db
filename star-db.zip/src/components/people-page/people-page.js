import React, { Component } from 'react';
import './people-page.css';
import ItemList from '../item-list';
import ItemDetails from '../item-details';
import ErrorIndicator from '../error-indicator';
import ErrorBoundary from '../error-boundary';
import SwapiService from '../../services/swapi-service';
import Row from '../row';
export default class PeoplePage extends Component{
  swapiService = new SwapiService();
    state = {
        selectedPerson: 3
    };
    onPersonSelected = (id) => {
        this.setState({
         selectedPerson: id
        })
        };
    render(){
        if(this.state.hasError){
            return <ErrorIndicator/>;
        }
        const itemList = (
          <ItemList 
            onItemSelected={this.onPersonSelected}
            getData={this.swapiService.getAllPeople} 
            renderItem={({name, gender, birthYear}) => `${name} (${gender}, ${birthYear})`}/>
        );
        const personDetails = (
          <ErrorBoundary> 
          <ItemDetails itemId={this.state.selectedPerson}/>
          </ErrorBoundary>
        );
        return (
       
        <div>
        <Row left={itemList} right={personDetails}/>
        </div>
        );
    }
}