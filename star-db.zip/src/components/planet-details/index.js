import PlanetDetails from './planet-details';
export default PlanetDetails;