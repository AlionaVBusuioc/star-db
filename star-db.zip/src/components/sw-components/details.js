import React from 'react';
const PersonDetails = () => {};
const PlanetDetails = () => {};
const StarshipDetails = () => {};

export {
    PersonDetails,
    PlanetDetails,
    StarshipDetails
};