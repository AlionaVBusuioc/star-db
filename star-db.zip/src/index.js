import React from 'react';
import ReactDOM from 'react-dom';
/* import './index.css'; */
import App from './components/app';
/* import * as serviceWorker from './serviceWorker'; */

//cu async - > cum resultatul va fi dispononibil se va inscrie in res
//await o sa astepte pina cind resultatul va fi disponibil si-l va inscrie in body
/* const getResource = async(url) => {  
 const res = await fetch(url); */
 //pentru erori -> sa intoarca asa raspuns in caz ca nu e corect linkul spre server
/*  if(!res.ok){
     throw new Error(`Could not fetch ${url}` + `, received ${res.status}`)
 } */
/*  const body = await res.json();
 return body; */
/*  return await res.json();
}; */

/* getResource('https://swapi.co/api/planets/1/')
.then((body) =>{
    console.log(body);
}) */
//Fetch reject promise
//daca e problema cu netul - sa-mi arate eroarea de mai jos
/* .catch((err) =>{
    console.log('Could not fetch',err);
}); */

/* fetch('https://swapi.co/api/planets/1/')
.then((res) =>{ */
    /* console.log('Got Response', res.status); */
/*     return res.json();
})
.then((body) =>{
    console.log(body);
}); */

ReactDOM.render(<App/>, document.getElementById('root'));

// If you want your app to work offline and load faster, you can change
// unregister() to register() below. Note this comes with some pitfalls.
// Learn more about service workers: https://bit.ly/CRA-PWA
/* serviceWorker.unregister(); */
